DROP DATABASE IF EXISTS q1;

CREATE DATABASE IF NOT EXISTS q1;
USE q1;

CREATE TABLE owner (
	ownerno       VARCHAR(30) NOT NULL,
	fname         VARCHAR(30) NOT NULL,
	lname         VARCHAR(30) NOT NULL,
	adress		  VARCHAR(30) NOT NULL,
	telno		  VARCHAR(30) NOT NULL,
	PRIMARY KEY (ownerno)
);




CREATE TABLE property(
	propertyno    VARCHAR(30) NOT NULL,
	street    	  VARCHAR(30) NOT NULL,
	country    	  VARCHAR(30) NOT NULL,
	typee    	  VARCHAR(30) NOT NULL,
	rooms         INT 	      NOT NULL,
	rent          INT 	      NOT NULL,
	yearincome    INT 	      NOT NULL,
	ownerno       VARCHAR(30) NOT NULL,
	PRIMARY KEY (propertyno),
	FOREIGN KEY (ownerno) REFERENCES owner(ownerno)ON DELETE CASCADE
);




-- call insert_in_property('PA14' ,'16','Holhead','Barbados' ,'Villa' ,'6' ,'500' ,'12000' ,'CO46') ##



CREATE TABLE client (
	clientno      VARCHAR(30) NOT NULL,
	fname         VARCHAR(30) NOT NULL,
	lname         VARCHAR(30) NOT NULL,
	telno		  VARCHAR(30) NOT NULL,
	perftype	  VARCHAR(30) NOT NULL,
	maxrent		  INT 		  NOT NULL,
	PRIMARY KEY (clientno)
);


CREATE TABLE booking(

	clientno  	  VARCHAR(30) NOT NULL,
	propertyno    VARCHAR(30) NOT NULL,
	bookingdate   DATE  	  NOT NULL,
	comment 	  VARCHAR(20) NOT NULL,
	FOREIGN KEY (clientno) REFERENCES client(clientno) ON DELETE CASCADE,
	FOREIGN KEY (propertyno) REFERENCES property(propertyno) ON DELETE CASCADE

);

delimiter ##
CREATE PROCEDURE insert_owner(IN a Varchar(30),IN b varchar(30),IN c varchar(30),IN d varchar(30), IN e varchar(30))
BEGIN
insert into owner(ownerno,fname,lname,adress, telno) values (a,b,c,d,e);
END ##

call insert_owner('001','Mubariz', 'Khan', 'l street', '082392')##
call insert_owner('CO46' ,'Joe', 'Keogh', '2 Fergus Dr Aberdeen AB2 7SX','01224-961212')##
call insert_owner('CO40', 'Tina', 'Murphy', '63 Well St, Glasgow', 'G42 0141-943-1728');




delimiter ##
CREATE PROCEDURE insert_client1(IN a Varchar(30),IN b varchar(30),IN c varchar(30),IN d varchar(30), IN e varchar(30), IN f INT)
BEGIN
insert into client(clientno,fname,lname,telno, perftype, maxrent) values (a,b,c,d,e,f);
END ##

call insert_client1('CR76' ,'John' ,'Kay' ,'0207-774-5632','Villa' ,500)
call insert_client1('CR56' ,'Aline' ,'Stewart','0141-848-1825', 'Apartment', 475)##
call insert_client1('CR74', 'Mike',' Ritchie',' 01475-392178', 'Studio', 525)##





delimiter ##
CREATE PROCEDURE insert_in_property(IN a Varchar(30),IN b varchar(30),IN c varchar(30),IN d varchar(30), IN e INT,
In f INT, In g INT, In h varchar(30) ) 
BEGIN
insert into property(propertyno,street,country,typee, rooms, rent, yearincome, ownerno) 
    values (a,b,c,d,e,f,g,h);
END ##



delimiter ##
CREATE PROCEDURE insert_booking(IN a Varchar(30),IN b varchar(30),IN c varchar(30),IN d varchar(30))
BEGIN
insert into booking(clientno,propertyno,bookingdate,comment) values (a,b,c,d);
END ##

call insert_booking('CR76' ,'PG4' ,'09/07/2007' ,'Special Diet');
call insert_booking('CR56' ,'PA14' ,'16/07/2007 ','Non smokingRequired');
call insert_booking('CR716' ,'PG4' ,'09/07/2007' ,'Special Diet')
call insert_booking('CR62' ,'PA14', '03/09/2007', 'Allergies');


Q3
.
SELECT type,country,owner.ownerno,owner.fname,owner.address 
from property,owner;

SELECT propertno,street,country,type 
from property,client where property.type = client.preftype;


SELECT fname,lname,address,telno,propertyno,type 
from property,owner 
where property.type = 'Villa' and 'Apartments';

SELECT min(rent) from property;

SELECT clientno, lname,bookingdate,propertyno,country,preftype 
from booking,property,client;

SELECT propertno,street,country,type,ownerno 
from owner,property;

SELECT clientno,fname,lname,telno 
from  client,property 
where property.type = 'Villa' and property.room = 6;





5. 

CREATE USER 'mubariz'@'localhost' IDENTIFIED BY 'khan';
GRANT ALL PRIVILEGES ON * . * TO 'mubariz'@'localhost'


