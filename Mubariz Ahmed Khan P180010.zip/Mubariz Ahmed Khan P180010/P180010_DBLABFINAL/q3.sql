
Q3: Mubariz Khan P180010

1
select count(employee_id), manager_id, department_id from employees group by manager_id;

2
SELECT first_name, last_name, salary, department_id 
FROM employees  
WHERE salary IN  
(SELECT MIN(salary) FROM employees GROUP BY department_id);

5.SELECT  first_name, last_name, hire_date 
FROM employees 
WHERE department_id =( SELECT department_id FROM employees 
WHERE first_name = 'Bruce')  AND first_name <> 'Bruce';

6.select avg(salary) from employees 
where salary > (select max(salary) from  
employees where employee_id in (select manager_id from employees)) group by job_id;


3
select first_name from employees where salary < ANY (select salary from employees where job_id="SH_CLERK" or job_id="ST_CLERK" or job_id="PU_CLERK");

4
SELECT * FROM employees WHERE salary > ALL(SELECT avg(salary)FROM employees GROUP BY department_id);
