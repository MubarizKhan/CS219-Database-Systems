<?php 
    $server = "localhost";
    $user = "root";
    $pass = "";
    $dbname = "db_lab";

    $con = new MySQLi($server, $user, $pass, $dbname);
    
    if($con->connect_error)
    {
        echo "<script>alert('not connected')</script>";
        echo "Error: ".$con->connect_error;
    }


 ?>