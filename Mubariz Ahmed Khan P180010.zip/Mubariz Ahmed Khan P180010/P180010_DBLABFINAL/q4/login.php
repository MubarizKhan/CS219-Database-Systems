<?php

    include "connect.php";

    $email = $_POST["email"];
    $password = $_POST["password"];

    $qry = "SELECT email, password from registeration where email='$email' && password='$password'";
    if ($con->query($qry)){
        echo "Your are login";
    }
    else{
        echo " Your pass word is wrong !!!! ";
        echo " also Check email name !!";
    }

?>