<?php

    include "connect.php";
    
    $nationality = $_POST["nationality"];
    $cnic = $_POST["cnic"];
    $mobile_no = $_POST["mobile_no"];
    $email = $_POST["email"];
    $re_email = $_POST["retype_email"];
    $password = $_POST["password"];
    $re_password = $_POST["retype_password"];
    $degree = $_POST["degree"];

    if ($email == $re_email){
        $var1 = true;
    }
    else{
        echo"Email is incorrect";
    }
    if ($password == $re_password){
        $var2 = true;
    }
    else{
        echo "Password is incorrect";
    }

    if ($var1 == $var2) {

        $qry = "INSERT INTO registeration (email ,  password, nationality, degree,cnic , mobile_no) VALUES('".$email."','".$password."','".$nationality."','".$degree."','".$cnic."','".$mobile_no."' )";

        if ($con->query($qry)){
            echo "Data Entered Successfully";
        }
        else{
            echo $con->error;
        }
    }



?>