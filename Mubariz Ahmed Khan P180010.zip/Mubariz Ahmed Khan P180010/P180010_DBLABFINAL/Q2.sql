Q1
select goal.teamid, goal.player, goal.matchid from goal,game  where teamid like '%RUS%' and game.ID = goal.MatchID;

Q3
MariaDB [football]> select goal.Teamid,goal.player,goal.Gtime, eteam.Coach from goal, eteam where goal.Gtime < 10;
Empty set (0.001 sec)

Q4
select game.Mdate, goal.Matchid from game,goal,eteam where game.team1 like '%gre%' and eteam.coach like '%Fernando Santos%';

Q5

select goal.Player from game, goal, eteam where game.stadium like '%National Stadium, Warsaw%' and game.ID = goal.Matchid;


Q6
SELECT player FROM goal LEFT JOIN game ON matchid = id WHERE (team1 = 'GRE' OR team2 = 'GRE') AND teamid != 'GRE';

Q2
SELECT team1, team2, player FROM game INNER JOIN goal ON id = matchid WHERE player = 'Alan Dzagoev';

Q9

SELECT id , Mdate ,
COUNT(*) from game  
JOIN (SELECT matchid , gtime from goal) as dt
 on id = dt.matchid WHERE team1 = 'POL' or team2 = 'POL' GROUP BY id , Mdate;


Q10

SELECT id , Mdate , 
COUNT(*) from game  
JOIN (SELECT matchid , gtime from goal where teamid = 'POL') as dt on id = dt.matchid GROUP BY id , Mdate;
