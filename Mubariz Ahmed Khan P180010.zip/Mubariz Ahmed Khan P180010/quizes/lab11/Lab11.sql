
CREATE PROCEDURE insert_in_users1(IN a INT,IN b INT,IN c INT,IN d INT)
BEGIN
insert into users(user_id,username,password,email) values (a,b,c,d);
END##


create trigger `trig1` after insert
on lab11.`users`
for each row begin
if new.user_id then
    set @total_users = new.user_id;
end if;

insert into summary(total_users) values (@total_users);

end##



create trigger `trig2` after insert
on lab11.`users`
for each row begin
if new.email like `yahoo%';
    set @yahoo = @yahoo + 1;
end if;
insert into summary(yahoo) values (@yahoo);
end##


create trigger `trig2` after insert
on lab11.`users`
for each row begin
if new.email like `hotmail%`;
    set @hotmail = @hotmail + 1;
end if;
insert into summary(hotmail) values (@hotmail);
end##

create trigger `trig3` after insert
on lab11.`users`
for each row begin
if new.email like `gmail%`;
    set @gmail = @gmail + 1;
end if;
insert into summary(gmail) values (@gmail);
end##

