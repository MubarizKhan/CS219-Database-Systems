1.Display the name of the employee who earns highest salary

MariaDB [hr]> select first_name,last_name from employees where salary = (select max(salary) from employees);
+------------+-----------+
| first_name | last_name |
+------------+-----------+
| Steven     | King      |
+------------+-----------+
1 row in set (0.003 sec)

2.Display the employee number and name for employee working as clerk and earning highest salary among clerks
MariaDB [hr]> select employee_id, first_name,salary from employees where salary = (select max(salary) from employees where job_id like '%clerk%');
+-------------+------------+---------+
| employee_id | first_name | salary  |
+-------------+------------+---------+
|         107 | Diana      | 4200.00 |
|         184 | Nandita    | 4200.00 |
+-------------+------------+---------+
2 rows in set (0.001 sec)


3.Display the names of accountantwho earns a salary more than the highest salary of any clerk.
MariaDB [hr]> select employee_id, first_name,salary from employees where job_id like '%account%' having salary > (select max(salary) from employees where job_id like '%clerk%');
+-------------+-------------+---------+
| employee_id | first_name  | salary  |
+-------------+-------------+---------+
|         109 | Daniel      | 9000.00 |
|         110 | John        | 8200.00 |
|         111 | Ismael      | 7700.00 |
|         112 | Jose Manuel | 7800.00 |
|         113 | Luis        | 6900.00 |
|         206 | William     | 8300.00 |
+-------------+-------------+---------+
6 rows in set (0.001 sec)



4.Display the names of clerks who earn a salary more than the lowest salary of any programmer. 
MariaDB [hr]> select employee_id, first_name,salary from employees where job_id like '%clerk%' having salary > (select min(salary) from employees where job_id like '%prog%');
Empty set (0.001 sec)

5.Display the names of employees who earn a salary more than that of Peteror that of salary greater than that of Lisa.
MariaDB [hr]> select salary from employees where salary > first_name like '%peter%' or '%lisa%';
+----------+
| salary   |
+----------+
| 24000.00 |
| 17000.00 |
| 17000.00 |

6.Issue a query to list all the employees who salary is > the average salary of their own dept. 
MariaDB [hr]> select first_name from employees where salary > all(select avg(salary) from employees group by department_id);
+------------+
| first_name |
+------------+
| Steven     |
+------------+
1 row in set (0.001 sec)

7.Display the names of the employees who earn highest salary in their respective departments.
MariaDB [hr]> select first_name,last_name,department_id,max(salary) from employees group by department_id;
+------------+-----------+---------------+-------------+
| first_name | last_name | department_id | max(salary) |
+------------+-----------+---------------+-------------+
| Kimberely  | Grant     |          NULL |     7000.00 |
| Jennifer   | Whalen    |            10 |     4400.00 |
| Michael    | Hartstein |            20 |    13000.00 |
| Den        | Raphaely  |            30 |    11000.00 |
| Susan      | Mavris    |            40 |     6500.00 |
| Matthew    | Weiss     |            50 |     8200.00 |
| Alexander  | Hunold    |            60 |     9000.00 |
| Hermann    | Baer      |            70 |    10000.00 |
| John       | Russell   |            80 |    14000.00 |
| Steven     | King      |            90 |    24000.00 |
| Nancy      | Greenberg |           100 |    12000.00 |
| Shelley    | Higgins   |           110 |    12000.00 |
+------------+-----------+---------------+-------------+
12 rows in set (0.001 sec)

8.
MariaDB [hr]> select e.first_name, j.job_title from employees e join departments d on e.department_id = d.department_id join jobs j on j.job_id = e.job_id where e.department_id = 20 and e.job_id in (select job_id from employees where department_id = 50);
Empty set (0.008 sec)


9.Display the names of the employees who earn highest salaries in their respective job groups.
MariaDB [hr]> select first_name, salary, department_id from employees where salary in (select max(salary) from employees group by job_id);

11.Display the employee names who are working in Finance department
MariaDB [hr]> select first_name, department_id from employees where department_id in (select department_id from employees where department_id = 100);
+-------------+---------------+
| first_name  | department_id |
+-------------+---------------+
| Nancy       |           100 |
| Daniel      |           100 |
| John        |           100 |
| Ismael      |           100 |
| Jose Manuel |           100 |
| Luis        |           100 |
+-------------+---------------+
6 rows in set (0.001 sec)

12.
MariaDB [hr]> select first_name,job_id from employees where salary > (select max(salary) from employees where department_id = 20 and department_id = 30);
Empty set (0.001 sec)

13.
MariaDB [hr]> select e.first_name, d.location_id from employees e join departments d on d.department_id = e.department_id where location_id = (select location_id from locations where city = 'Sydney');
Empty set (0.001 sec)


14.
MariaDB [hr]> select * from employees where department_id = (select department_id from employees where department_id = 10);
+-------------+------------+-----------+---------+--------------+------------+---------+---------+----------------+------------+---------------+
| employee_id | first_name | last_name | email   | phone_number | hire_date  | job_id  | salary  | commission_pct | manager_id | department_id |
+-------------+------------+-----------+---------+--------------+------------+---------+---------+----------------+------------+---------------+
|         200 | Jennifer   | Whalen    | JWHALEN | 515.123.4444 | 1987-09-17 | AD_ASST | 4400.00 |           NULL |        101 |            10 |
+-------------+------------+-----------+---------+--------------+------------+---------+---------+----------------+------------+---------------+
1 row in set (0.001 sec)

15.Display the Job groups having total salary greater than the maximum salary for managers.
MariaDB [hr]> select job_id,job_title from jobs group by job_id having sum(max_salary) > (select max(max_salary) from jobs where job_title like '%manager%');
+---------+-------------------------------+
| job_id  | job_title                     |
+---------+-------------------------------+
| AD_PRES | President                     |
| AD_VP   | Administration Vice President |
+---------+-------------------------------+
2 rows in set (0.001 sec)

16.
MariaDB [hr]> select department_name from departments where department_id in (select department_id from employees group by department_id having max(salary) > 9000);
+------------------+
| department_name  |
+------------------+
| Marketing        |
| Purchasing       |
| Public Relations |
| Sales            |
| Executive        |
| Finance          |
| Accounting       |
+------------------+
7 rows in set (0.006 sec)

17.
MariaDB [hr]> select first_name from employees e where e.department_id = 10 and salary > any (select salary from employees where department_id != 10);
+------------+
| first_name |
+------------+
| Jennifer   |
+------------+
1 row in set (0.001 sec)

18.
MariaDB [hr]> select first_name from employees where job_id like (select job_id from employees where department_id in (select department_id from departments where location_id = 2700));
+------------+
| first_name |
+------------+
| Hermann    |
+------------+
1 row in set (0.001 sec)

19.
select e.first_name, d.department_name, j.job_title, l.city from employees e join departments d on e.department_id = d.department_id join jobs j on e.job_id = j.job_id join locations l on d.location_id = l.location_id
+-------------+------------------+---------------------------------+---------------------+
| first_name  | department_name  | job_title                       | city                |
+-------------+------------------+---------------------------------+---------------------+
| William     | Accounting       | Public Accountant               | Seattle             |
| Shelley     | Accounting       | Accounting Manager              | Seattle             |
| Jennifer    | Administration   | Administration Assistant        | Seattle             |
| Steven      | Executive        | President                       | Seattle             |
| Neena       | Executive        | Administration Vice President   | Seattle             |
| Lex         | Executive        | Administration Vice President   | Seattle             |
| Daniel      | Finance          | Accountant                      | Seattle             |
| John        | Finance          | Accountant                      | Seattle             |
| Ismael      | Finance          | Accountant                      | Seattle             |
| Jose Manuel | Finance          | Accountant                      | Seattle             |
| Luis        | Finance          | Accountant                      | Seattle             |
| Nancy       | Finance          | Finance Manager                 | Seattle             |
| Susan       | Human Resources  | Human Resources Representative  | London              |
| Alexander   | IT               | Programmer                      | Southlake           |
| Bruce       | IT               | Programmer                      | Southlake           |
| David       | IT               | Programmer                      | Southlake           |
| Valli       | IT               | Programmer                      | Southlake           |
| Diana       | IT               | Programmer                      | Southlake           |
| Michael     | Marketing        | Marketing Manager               | Toronto             |
| Pat         | Marketing        | Marketing Representative        | Toronto             |
| Hermann     | Public Relations | Public Relations Representative | Munich              |
| Alexander   | Purchasing       | Purchasing Clerk                | Seattle             |
| Shelli      | Purchasing       | Purchasing Clerk                | Seattle             |
| Sigal       | Purchasing       | Purchasing Clerk                | Seattle             |
| Guy         | Purchasing       | Purchasing Clerk                | Seattle             |
| Karen       | Purchasing       | Purchasing Clerk                | Seattle             |
| Den         | Purchasing       | Purchasing Manager              | Seattle             |
| John        | Sales            | Sales Manager                   | Oxford              |
| Karen       | Sales            | Sales Manager                   | Oxford              |
| Alberto     | Sales            | Sales Manager                   | Oxford              |
| Gerald      | Sales            | Sales Manager                   | Oxford              |
| Eleni       | Sales            | Sales Manager                   | Oxford              |
| Peter       | Sales            | Sales Representative            | Oxford              |
| David       | Sales            | Sales Representative            | Oxford              |
| Peter       | Sales            | Sales Representative            | Oxford              |
| Christopher | Sales            | Sales Representative            | Oxford              |
| Nanette     | Sales            | Sales Representative            | Oxford              |
| Oliver      | Sales            | Sales Representative            | Oxford              |
| Janette     | Sales            | Sales Representative            | Oxford              |
| Patrick     | Sales            | Sales Representative            | Oxford              |
| Allan       | Sales            | Sales Representative            | Oxford              |
| Lindsey     | Sales            | Sales Representative            | Oxford              |
| Louise      | Sales            | Sales Representative            | Oxford              |
| Sarath      | Sales            | Sales Representative            | Oxford              |
| Clara       | Sales            | Sales Representative            | Oxford              |
| Danielle    | Sales            | Sales Representative            | Oxford              |
| Mattea      | Sales            | Sales Representative            | Oxford              |
| David       | Sales            | Sales Representative            | Oxford              |
| Sundar      | Sales            | Sales Representative            | Oxford              |
| Amit        | Sales            | Sales Representative            | Oxford              |
| Lisa        | Sales            | Sales Representative            | Oxford              |
| Harrison    | Sales            | Sales Representative            | Oxford              |
| Tayler      | Sales            | Sales Representative            | Oxford              |
| William     | Sales            | Sales Representative            | Oxford              |
| Elizabeth   | Sales            | Sales Representative            | Oxford              |
| Sundita     | Sales            | Sales Representative            | Oxford              |
| Ellen       | Sales            | Sales Representative            | Oxford              |
| Alyssa      | Sales            | Sales Representative            | Oxford              |
| Jonathon    | Sales            | Sales Representative            | Oxford              |
| Jack        | Sales            | Sales Representative            | Oxford              |
| Charles     | Sales            | Sales Representative            | Oxford              |
| Winston     | Shipping         | Shipping Clerk                  | South San Francisco |
| Jean        | Shipping         | Shipping Clerk                  | South San Francisco |
| Martha      | Shipping         | Shipping Clerk                  | South San Francisco |
| Girard      | Shipping         | Shipping Clerk                  | South San Francisco |
| Nandita     | Shipping         | Shipping Clerk                  | South San Francisco |
| Alexis      | Shipping         | Shipping Clerk                  | South San Francisco |
| Julia       | Shipping         | Shipping Clerk                  | South San Francisco |
| Anthony     | Shipping         | Shipping Clerk                  | South San Francisco |
| Kelly       | Shipping         | Shipping Clerk                  | South San Francisco |
| Jennifer    | Shipping         | Shipping Clerk                  | South San Francisco |
| Timothy     | Shipping         | Shipping Clerk                  | South San Francisco |
| Randall     | Shipping         | Shipping Clerk                  | South San Francisco |
| Sarah       | Shipping         | Shipping Clerk                  | South San Francisco |
| Britney     | Shipping         | Shipping Clerk                  | South San Francisco |
| Samuel      | Shipping         | Shipping Clerk                  | South San Francisco |
| Vance       | Shipping         | Shipping Clerk                  | South San Francisco |
| Alana       | Shipping         | Shipping Clerk                  | South San Francisco |
| Kevin       | Shipping         | Shipping Clerk                  | South San Francisco |
| Donald      | Shipping         | Shipping Clerk                  | South San Francisco |
| Douglas     | Shipping         | Shipping Clerk                  | South San Francisco |
| Julia       | Shipping         | Stock Clerk                     | South San Francisco |
| Irene       | Shipping         | Stock Clerk                     | South San Francisco |
| James       | Shipping         | Stock Clerk                     | South San Francisco |
| Steven      | Shipping         | Stock Clerk                     | South San Francisco |
| Laura       | Shipping         | Stock Clerk                     | South San Francisco |
| Mozhe       | Shipping         | Stock Clerk                     | South San Francisco |
| James       | Shipping         | Stock Clerk                     | South San Francisco |
| TJ          | Shipping         | Stock Clerk                     | South San Francisco |
| Jason       | Shipping         | Stock Clerk                     | South San Francisco |
| Michael     | Shipping         | Stock Clerk                     | South San Francisco |
| Ki          | Shipping         | Stock Clerk                     | South San Francisco |
| Hazel       | Shipping         | Stock Clerk                     | South San Francisco |
| Renske      | Shipping         | Stock Clerk                     | South San Francisco |
| Stephen     | Shipping         | Stock Clerk                     | South San Francisco |
| John        | Shipping         | Stock Clerk                     | South San Francisco |
| Joshua      | Shipping         | Stock Clerk                     | South San Francisco |
| Trenna      | Shipping         | Stock Clerk                     | South San Francisco |
| Curtis      | Shipping         | Stock Clerk                     | South San Francisco |
| Randall     | Shipping         | Stock Clerk                     | South San Francisco |
| Peter       | Shipping         | Stock Clerk                     | South San Francisco |
| Matthew     | Shipping         | Stock Manager                   | South San Francisco |
| Adam        | Shipping         | Stock Manager                   | South San Francisco |
| Payam       | Shipping         | Stock Manager                   | South San Francisco |
| Shanta      | Shipping         | Stock Manager                   | South San Francisco |
| Kevin       | Shipping         | Stock Manager                   | South San Francisco |
+-------------+------------------+---------------------------------+---------------------+
106 rows in set (0.008 sec)

20.Display the employee(s) earning the second highest salary
MariaDB [hr]> select first_name, max(salary) from employees where salary <(select max(salary) from employees);
+------------+-------------+
| first_name | max(salary) |
+------------+-------------+
| Neena      |    17000.00 |
+------------+-------------+
1 row in set (0.001 sec)

21.
MariaDB [hr]> select d.department_name, count(e.department_id) from departments d join employees e on e.department_id = d.department_id group by e.department_id having count(e.department_id) < 3;
+------------------+------------------------+
| department_name  | count(e.department_id) |
+------------------+------------------------+
| Administration   |                      1 |
| Marketing        |                      2 |
| Human Resources  |                      1 |
| Public Relations |                      1 |
| Accounting       |                      2 |
+------------------+------------------------+
5 rows in set (0.001 sec)


